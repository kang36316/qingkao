<?php

/**
 * Class Config
 *
 * 执行Sample示例所需要的配置，用户在这里配置好Endpoint，AccessId， AccessKey和Sample示例操作的
 * bucket后，便可以直接运行RunAll.php, 运行所有的samples
 */
final class Config
{
    const OSS_ACCESS_ID = 'LTAIcnQuDKBFNsNU';
    const OSS_ACCESS_KEY = 'dRWGflyAfXJob4wtrc8fgIO5879GwV';
    const OSS_ENDPOINT = 'oss-cn-beijing.aliyuncs.com';
    const OSS_TEST_BUCKET = 'outin-9b1199c17e1b11ea8ae200163e1c8dba.oss-cn-beijing.aliyuncs.com';
}
